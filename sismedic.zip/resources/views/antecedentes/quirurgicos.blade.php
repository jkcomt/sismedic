<div class="col-md-12">
  <div class="row form-group">
    <div class="col-md-2">
    </div>
    <div class="col-md-4">
    </div>
    <div class="col-md-6 text-right">
      <button type="button" name="button" class="btn btn-sm btn-success">Guardar</button>
    </div>
  </div>

    <div class="row form-group">
          <div class="col-md-4">
            <div class="input-group">
              <span class="input-group-addon ">
                  <input type="checkbox" aria-label="">
              </span>
              <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Apendicectomía</span>
                  {{-- <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Indique el Año</span>
                <input type="text" class="form-control" aria-label="..."> --}}
            </div>
          </div>
          <div class="col-md-4">
            <div class="input-group">
            <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Indique el Año</span>
                <input type="text" class="form-control" aria-label="...">
            </div>
          </div>
    </div>

    <div class="row form-group">
          <div class="col-md-4">
            <div class="input-group">
              <span class="input-group-addon ">
                  <input type="checkbox" aria-label="">
              </span>
              <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Colecistectomía</span>
                  {{-- <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Indique el Año</span>
                <input type="text" class="form-control" aria-label="..."> --}}
            </div>
          </div>
          <div class="col-md-4">
            <div class="input-group">
            <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Indique el Año</span>
                <input type="text" class="form-control" aria-label="...">
            </div>
          </div>
    </div>


    <div class="row form-group">
          <div class="col-md-4">
            <div class="input-group">
              <span class="input-group-addon ">
                  <input type="checkbox" aria-label="">
              </span>
              <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Herniorrafia Umbilical</span>
                  {{-- <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Indique el Año</span>
                <input type="text" class="form-control" aria-label="..."> --}}
            </div>
          </div>
          <div class="col-md-4">
            <div class="input-group">
            <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Indique el Año</span>
                <input type="text" class="form-control" aria-label="...">
            </div>
          </div>
    </div>


    <div class="row form-group">
          <div class="col-md-4">
            <div class="input-group">
              <span class="input-group-addon ">
                  <input type="checkbox" aria-label="">
              </span>
              <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Herniorrafia Inguinal</span>
                  {{-- <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Indique el Año</span>
                <input type="text" class="form-control" aria-label="..."> --}}
            </div>
          </div>
          <div class="col-md-4">
            <div class="input-group">
            <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Indique el Año</span>
                <input type="text" class="form-control" aria-label="...">
            </div>
          </div>
    </div>

    <div class="row form-group">
          <div class="col-md-12">
            <div class="input-group">
              <span class="input-group-addon ">
                  <input type="checkbox" aria-label="">
              </span>
              <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Ocular</span>
              <input type="text" class="form-control" aria-label="...">
                  {{-- <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Indique el Año</span>
                <input type="text" class="form-control" aria-label="..."> --}}
            </div>
          </div>

    </div>

    <div class="row form-group">
          <div class="col-md-12">
            <div class="input-group">
              <span class="input-group-addon ">
                  <input type="checkbox" aria-label="">
              </span>
              <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Otorrino</span>
              <input type="text" class="form-control" aria-label="...">
                  {{-- <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Indique el Año</span>
                <input type="text" class="form-control" aria-label="..."> --}}
            </div>
          </div>

    </div>

    <div class="row form-group">
          <div class="col-md-4">
            <div class="input-group">
              <span class="input-group-addon ">
                  <input type="checkbox" aria-label="">
              </span>
              <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Obstetricia (Cesarea)</span>
                  {{-- <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Indique el Año</span>
                <input type="text" class="form-control" aria-label="..."> --}}
            </div>
          </div>
          <div class="col-md-4">

          </div>
    </div>

    <div class="row form-group">
          <div class="col-md-12">
            <div class="input-group">
              <span class="input-group-addon ">
                  <input type="checkbox" aria-label="">
              </span>
              <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Ginecológica (Cesarea)</span>
              <input type="text" class="form-control" aria-label="...">
                  {{-- <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Indique el Año</span>
                 --}}
            </div>
          </div>

    </div>

    <div class="row form-group">
          <div class="col-md-4">
            <div class="input-group">
              <span class="input-group-addon ">
                  <input type="checkbox" aria-label="">
              </span>
              <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Otras Cirugías</span>
                  {{-- <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Indique el Año</span>
                <input type="text" class="form-control" aria-label="..."> --}}
            </div>
          </div>
          <div class="col-md-4">
            <div class="input-group">
            <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Fecha</span>
                <input type="date" class="form-control" aria-label="...">
            </div>
          </div>
          <div class="col-md-4">
            <div class="input-group">
            <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Observaciones</span>
                <input type="text" class="form-control" aria-label="...">
            </div>
          </div>
    </div>

    </div>
