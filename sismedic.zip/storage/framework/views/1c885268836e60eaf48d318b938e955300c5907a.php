<div class="col-lg-12 col-md-12 col-sm-12">
    <table class="table table-responsive table-hover table-condensed small box" id="tabla">
        <thead>
        <th>Nro. CITA</th>
        <th>Nro. HISTORIA</th>
        <th>PACIENTE</th>
        <th>FECHA - HORA</th>
        <th>OPCIONES</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $citas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($cita->nro_serie_cita); ?></td>
                <td><?php echo e($cita->paciente->nro_historia); ?></td>
                <td class="text-left"><?php echo e($cita->paciente->apellido_paterno.' '.$cita->paciente->apellido_materno.' '.$cita->paciente->nombres); ?></td>
                <td><?php echo e($cita->fecha_examen.' - '.Carbon\Carbon::parse($cita->hora_examen)->format('h:i A')); ?></td>
                <td>
                    
                    <?php echo e(csrf_field()); ?>

                    <a href="<?php echo e(route('evaluacion_medica.create',$cita->id)); ?>" class="btn btn-xs btn-success"  id=""><span class="fa fa-plus"></span> REGISTRAR EVALUACION MEDICA</a>
                    
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($citas->links()); ?>

</div>
