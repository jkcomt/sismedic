
<div class="form-group" >
    <select name="departamentoOrigen" id="departamentoOrigen" class="form-control departamentoOrigen" >
        
        <?php if($departamentos): ?>
            <?php $__currentLoopData = $departamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $departamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>" <?php if(isset($paciente)): ?><?php if($paciente->departamentoOrigen->id == $key): ?> selected="selected" <?php endif; ?> <?php endif; ?>><?php echo e($departamento); ?></option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
</div>