<?php $__env->startSection('api'); ?>
    <style>
        th,td{
            text-align: center;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header','LISTADO DE FUNCIONES VITALES'); ?>
<?php $__env->startSection('modal-title'); ?>
    <h4 class="modal-title">Aviso</h4>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-body'); ?>
    <h3 class="text-success text-center">Eliminación Exitosa</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-footer'); ?>
    <a class="btn btn-sm btn-warning" href="">Volver</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal-confirmacion-title'); ?>
    <h4 class="modal-title">Aviso</h4>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-confirmacion-body'); ?>
    <h3 class="text-warning text-center">¿Desea eliminar el registro?</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-confirmacion-footer'); ?>
    <button class="btn btn-danger confirmar" id="">Confirmar</button>
    <a href="" class="btn btn-warning " data-dismiss="modal" id="index" >Volver</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    

    <div class="row">
        <div class="col-md-2">
            <div class="form-group">
                
            </div>
        </div>
        <div class="col-md-10">
            <form action="" class="form-inline text-right">
                <select name="filtro" id="filtro" class="form-control">
                    <option value="historia">Nro. Historia</option>
                    <option value="paciente">PACIENTE</option>
                </select>
                <input type="text" id="buscarFuncionVital" placeholder="BUSCAR..." class="form-control" style="width: 45%">

            </form>
        </div>
    </div>
    <br>
    <div class="row" id="tabla">
        <?php echo $__env->make('funcionvital.tabla', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/funcionvital.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>