<div class="col-lg-12 col-md-12 col-sm-12">
    <table class="table table-responsive table-hover table-condensed small box" id="tabla">
        <thead>
        <th>USUARIO</th>
        <th>CARGO</th>
        <th>PERSONAL</th>
        <th>OPCIONES</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($usuario->name); ?></td> 
                <td><?php echo e($usuario->cargo->descripcion); ?></td>  
                <td><?php echo e($usuario->personal->nombres." ".$usuario->personal->apellidos); ?></td>    
                 <td>
                   <button class="btn btn-xs btn-warning edit"  value="<?php echo e($usuario->id); ?>"><span class="glyphicon glyphicon-pencil"></span> EDITAR</button>
                    <?php echo e(csrf_field()); ?>

                    
                   
                    <button href="#" class="btn btn-xs btn-danger delete"  id="<?php echo e($usuario->id); ?>"><span class="glyphicon glyphicon-remove"></span> ELIMINAR</button>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php echo e($usuarios->links()); ?>

</div>