
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Sismedic</title>

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" crossorigin="anonymous">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="<?php echo e(asset('css/ie10-viewport-bug-workaround.css')); ?>" rel="stylesheet">

    <!-- Custom styles for this template -->




<!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="<?php echo e(asset('js/ie8-responsive-file-warning.js')); ?>"></script><![endif]-->
    <script src="<?php echo e(asset('js/ie-emulation-modes-warning.js')); ?>"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        body{
            font-size: 12px;
        }
        .center-text{
            text-align: center;
        }
        .padding-top{
            padding-top: 30px;
            border: hidden;
        }

    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <table>
            <tr>
                <td style="padding-right: 10px;">
                    <img src="<?php echo e(asset('img/logo.ico/logo.jpg')); ?>" alt="" width="80px" height="100px" >
                </td>
                <td >
                    
                    <h5>Dirección: Calle Los Girasoles 274 Urb. California, Trujillo</h5>
                    <h5>Teléfono: (044) 322600</h5>
                    <h5>Email: contacto@ciabumedical.com</h5>
                    
                    
                </td >
            </tr>
        </table>
    </div>
    <hr>
    <div class="row">
        <h4>Historial de Paciente</h4>
        <table class="table table-condensed ">
            <tr>
                <td><strong>Nro. Historia : </strong> <?php echo e($paciente->nro_historia); ?></td>
                <td><strong>Matrícula : </strong> <?php echo e($paciente->matricula); ?></td>
                <td colspan="2"></td>
            </tr>
            <tr>
                <td><strong>Ape. Paterno: </strong> <?php echo e($paciente->apellido_paterno); ?></td>
                <td><strong>Ape. Materno: </strong> <?php echo e($paciente->apellido_materno); ?></td>
                <td><strong>Nombres: </strong> <?php echo e($paciente->nombres); ?></td>
                <td><strong>Sexo: </strong> <?php echo e(ucfirst($paciente->sexo)); ?></td>
            </tr>
            <tr>
                <td><strong>Fecha Nacimiento : </strong> <?php echo e($paciente->fecha_nacimiento); ?></td>
                <td><strong>Edad : </strong> <?php echo e(\Carbon\Carbon::parse($paciente->fecha_nacimiento)->age.' años'); ?></td>
                <td colspan="2"></td>
            </tr>
            <tr>
                <td><strong>Fecha Ingreso : </strong> <?php echo e($paciente->fecha_ingreso); ?></td>
                <td><strong>Edad al ingresar : </strong> <?php echo e(\Carbon\Carbon::parse($paciente->fecha_ingreso)->age.' años'); ?></td>
                <td colspan="2"><strong>Fecha Ingreso a minera : </strong> <?php echo e($paciente->fecha_ingreso_minera); ?></td>
            </tr>
            <tr>
                <td colspan="4"><strong>Jefe Inmediato : </strong> <?php echo e($paciente->jefe_inmediato); ?></td>
            </tr>
        </table>
            
        
    </div>
    <div class="row">
        
            
                <table class="table table-condensed">
                    <tr><td  colspan="4"><strong>Lugar de Nacimiento</strong></td></tr>
                    <tr>
                        <td><strong>País : </strong> <?php echo e($paciente->paisOrigen->nombre); ?></td>
                        <td><strong>Departamento : </strong> <?php echo e($paciente->departamentoOrigen->nombre); ?></td>
                        <td><strong>Provincia : </strong> <?php echo e($paciente->provinciaOrigen->nombre); ?></td>
                        <td><strong>Distrito : </strong> <?php echo e($paciente->distritoOrigen->nombre); ?></td>
                    </tr>
                    <tr><td  colspan="4"><strong>Domicilio</strong></td></tr>
                    <tr>
                        <td><strong>País : </strong> <?php echo e($paciente->paisDomicilio->nombre); ?></td>
                        <td><strong>Departamento : </strong> <?php echo e($paciente->departamentoDomicilio->nombre); ?></td>
                        <td><strong>Provincia : </strong> <?php echo e($paciente->provinciaDomicilio->nombre); ?></td>
                        <td><strong>Distrito : </strong> <?php echo e($paciente->distritoDomicilio->nombre); ?></td>
                    </tr>
                    <tr><td colspan="4"><strong>Dirección : </strong> <?php echo e($paciente->direccion); ?></td></tr>
                </table>
            
        
    </div>
    <div class="row">
        <table class="table table-condensed">
            <tr>
                <td><strong>Telf. Fijo : </strong> <?php echo e($paciente->telf_fijo); ?></td>
                <td><strong>Móvil : </strong> <?php echo e($paciente->celular); ?></td>
                <td><strong>Trabajo : </strong> <?php echo e($paciente->celular); ?></td>
            </tr>
            <tr>
                <td><strong>Tipo Doc. Identidad : </strong> <?php echo e($paciente->tipo_dni); ?></td>
                <td><strong>Número Doc. Identidad : </strong> <?php echo e($paciente->num_dni); ?></td>
                <td colspan="2"></td>
            </tr>
            <tr>
                <td><strong>Estado Civil : </strong> <?php echo e($paciente->estado_civil); ?></td>
                <td><strong>Cant. Hijos Vivos : </strong> <?php echo e($paciente->nro_hijo_vivos); ?></td>
                <td><strong>Cant. Hijos Muertos : </strong> <?php echo e($paciente->nro_hijo_muertos); ?></td>
            </tr>
        </table>
    </div>
    <div class="row">
        <table class="table table-condensed">
            <tr>
                <td><strong>Instrucción : </strong> <?php echo e(ucfirst($paciente->instruccion->nombre)); ?></td>
                <td><strong>Profesión : </strong> <?php echo e(ucfirst($paciente->profesion->nombre)); ?></td>
                <td><strong>Contrata : </strong> <?php echo e(ucfirst($paciente->contrata->nombre)); ?></td>
            </tr>
            <tr>
                <td><strong>Área : </strong> <?php echo e(ucfirst($paciente->area->nombre)); ?></td>
                <td><strong>Ocupación : </strong> <?php echo e(ucfirst($paciente->ocupacion->nombre)); ?></td>
                <td><strong>Sección : </strong> <?php echo e($paciente->seccion); ?></td>
            </tr>
            <tr>
                <td><strong>Labora en : </strong> <?php echo e(ucfirst($paciente->lugarLabores->nombre)); ?></td>
                <td colspan="2"><strong>Tiempo Desempeño : </strong> </td>
            </tr>
            <tr>
                <td><strong>Email : </strong> <?php echo e($paciente->email); ?></td>
                <td colspan="2"><strong>Altura : </strong> <?php echo e($paciente->altura->descripcion); ?></td>
            </tr>
            <tr>
                <td><strong>Comentarios : </strong> <?php echo e($paciente->comentarios); ?></td>
                <td colspan="2"><strong>Gs/Rh : </strong> <?php echo e($paciente->grupoSanguineo->descripcion); ?></td>
            </tr>
            <tr>
                <td><strong>Alergias : </strong> <?php echo e($paciente->alergias); ?></td>
                <td colspan="2"><strong>Regimen : </strong> <?php echo e($paciente->regimen->descripcion); ?></td>

            </tr>
            <tr>
                <td colspan="3"><strong>En caso de emergencia : </strong> <?php echo e($paciente->en_caso_emergencia); ?></td>

            </tr>

        </table>
    </div>
</div>
<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
<!-- Latest compiled and minified JavaScript -->
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<!-- Just to make our placeholder images work. Don't actually copy the next line! -->
<script src="<?php echo e(asset('js/holder.min.js')); ?>"></script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src="<?php echo e(asset('js/ie10-viewport-bug-workaround.js')); ?>"></script>
<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
</body>
</html>
