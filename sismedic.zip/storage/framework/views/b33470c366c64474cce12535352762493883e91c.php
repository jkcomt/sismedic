<section class="sidebar">

    <!-- Sidebar Menu -->
    <ul class="sidebar-menu" data-widget="tree">
        <li class="header">OPCIONES</li>
        <!-- Optionally, you can add icons to the links -->
        <li class="<?php echo e(Request::is('dashboard') ? 'active' : ''); ?>"><a href="/"><i class="fa fa-home"></i> <span>Principal</span></a></li>

        <li class="treeview <?php echo e(Request::is('pacientes/*') ? 'active' : ''); ?> <?php echo e(Request::is('pacientes') ? 'active' : ''); ?>">
            <a href="#"><i class="fa fa-user"></i> <span>Pacientes</span>
                <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
            </span>
            </a>
            <ul class="treeview-menu">
              <li class="<?php echo e(Request::is('pacientes/create') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('pacientes.create')); ?>"><i class="fa  fa-plus-circle"></i> <span>Registrar Paciente</span></a>
              </li>
              <li class="<?php echo e(Request::is('pacientes') ? 'active' : ''); ?> <?php echo e(Request::is('pacientes/citas/*') ? 'active' : ''); ?> <?php echo e(Request::is('pacientes/*/edit') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('pacientes.index')); ?>"><i class="fa fa-list-alt"></i> <span>Catálogo</span></a>
              </li>
                
                    
                
            </ul>
        </li>
        <li class="treeview <?php echo e(Request::is('citas/*') ? 'active' : ''); ?> <?php echo e(Request::is('citas') ? 'active' : ''); ?>">
            <a href="#"><i class="fa fa-address-book"></i> <span>Citas</span>
                <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
            </span>
            </a>
            <ul class="treeview-menu">
                <li class="<?php echo e(Request::is('citas/nueva_cita') ? 'active' : ''); ?>"><a href="<?php echo e(route('citas.nuevacita')); ?>"><i class="fa fa-plus-circle"></i> <span>Nueva Cita</span></a></li>
                <li class="<?php echo e(Request::is('citas/catalogo') ? 'active' : ''); ?>"><a href="<?php echo e(route('citas.catalogo')); ?>"><i class="fa fa-list-alt"></i> <span>Catalogo</span></a></li>
                <li  class="<?php echo e(Request::is('citas') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('calendario.index')); ?>"><i class="fa fa-calendar"></i> <span>Calendario</span></a>
                </li>
            </ul>
        </li>
        <li class="<?php echo e(Request::is('funcion_vital/*') ? 'active' : ''); ?> <?php echo e(Request::is('funcion_vital') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('funcion_vital.index')); ?>">
                <i class="fa fa-stethoscope"></i><span>Funciones Vitales</span>
            </a>
        </li>
        <li class="<?php echo e(Request::is('evaluacion_medica/*') ? 'active' : ''); ?> <?php echo e(Request::is('evaluacion_medica') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('evaluacion_medica.index')); ?>">
                <i class="fa fa-heartbeat"></i><span>Evaluación Médica</span>
            </a>
        </li>

        <li class="">
            <a href="#">
                <i class="fa fa-file-text"></i><span>Reportes</span>
            </a>
        </li>
        <li class="<?php if(Request::is('configuracion')): ?> active <?php elseif(Request::is('area')): ?> active <?php elseif(Request::is('altura')): ?> active <?php elseif(Request::is('contrata')): ?> active <?php elseif(Request::is('lugarlabor')): ?> active <?php elseif(Request::is('ocupaciones')): ?> active <?php elseif(Request::is('gruposanguineo')): ?> active <?php elseif(Request::is('profesion')): ?> active  <?php elseif(Request::is('tipoinstruccion')): ?> active <?php elseif(Request::is('perfil')): ?> active   <?php elseif(Request::is('cliente_cuenta')): ?> active   <?php elseif(Request::is('tipo_examen')): ?> active   <?php elseif(Request::is('lista_examen')): ?> active <?php elseif(Request::is('perfil_examen')): ?> active <?php elseif(Request::is('perfil_examen/*')): ?> active <?php elseif(Request::is('cargo')): ?> active  <?php elseif(Request::is('usuario')): ?> active <?php elseif(Request::is('personal')): ?> active  <?php endif; ?> ">
            <a href="<?php echo e(route('configuracion.index')); ?>">
                <i class="fa fa-gear"></i><span>Configuración</span>
            </a>
        </li>
        <?php if(auth()->user()->cargo->descripcion != 'secado'): ?>
            
        <?php endif; ?>

        <?php if(auth()->user()->cargo->descripcion != 'recepcion'): ?>

            
        <?php endif; ?>

    </ul>
    <!-- /.sidebar-menu -->
</section>
