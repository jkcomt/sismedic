<div class="col-lg-12 col-md-12 col-sm-12">
    <table class="table table-responsive table-hover table-condensed small box" id="tabla">
        <thead>
        <th>NOMBRE</th>
        <th>OPCIONES</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $contratas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contrata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($contrata->nombre); ?></td>
                <td>
                   <button class="btn btn-xs btn-warning edit"  value="<?php echo e($contrata->id); ?>"><span class="glyphicon glyphicon-pencil"></span> EDITAR</button>
                    <?php echo e(csrf_field()); ?>

                    
                   
                    <button href="#" class="btn btn-xs btn-danger delete"  id="<?php echo e($contrata->id); ?>"><span class="glyphicon glyphicon-remove"></span> ELIMINAR</button>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php echo e($contratas->links()); ?>

</div>