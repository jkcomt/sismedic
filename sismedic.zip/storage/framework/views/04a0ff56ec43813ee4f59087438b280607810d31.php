<div class="modal fade" tabindex="-1" role="dialog" id="modal-citas-lista">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Listado de Citas</h4>
            </div>
            
            <div class="modal-body ">
                    <?php echo e(csrf_field()); ?>

                    <div class="row">
                        <div class="col-md-12" style="max-height:60vh; overflow-y:scroll;">
                            <table class="table table-responsive table-hover table-condensed small box">
                                <thead>
                                <th>Nro. CITA</th>
                                <th>PACIENTE</th>
                                <th>FECHA - HORA</th>
                                <th>OPCIONES</th>
                                </thead>
                                <tbody>
                                <?php if(isset($citas)): ?>
                                <?php $__currentLoopData = $citas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($cita->nro_serie_cita); ?></td>
                                        <td><?php echo e($cita->paciente->apellido_paterno.' '.$cita->paciente->apellido_materno.' '.$cita->paciente->nombres); ?></td>
                                        <td><?php echo e($cita->fecha_examen.' - '.Carbon\Carbon::parse($cita->hora_examen)->format('h:i A')); ?></td>
                                        <td>
                                            <?php echo e(csrf_field()); ?>

                                            
                                            <?php if(isset($cita->funcionVital)): ?>
                                                
                                                <a href="<?php echo e(route('funcion_vital.show',$cita)); ?>" class="btn btn-xs btn-success"  id=""><span class="glyphicon glyphicon-info-sign"></span> DETALLE DE FUNCIONES VITALES</a>
                                                <?php else: ?>
                                                <a href="<?php echo e(route('funcion_vital.create',$cita->id)); ?>" class="btn btn-xs btn-info"  id=""><span class="glyphicon glyphicon-info-sign"></span> REGISTRAR FUNCIONES VITALES</a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
            </div>
            <div class="modal-footer">
                <div class="row">
                    <div class="col-md-12 text-right">
                        <a href="" class="btn btn-warning" data-dismiss="modal">Volver</a>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</div>
