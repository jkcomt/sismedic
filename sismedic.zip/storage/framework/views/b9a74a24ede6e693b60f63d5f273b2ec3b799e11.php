<div class="form-group">
    <select name="provinciaOrigen" id="provinciaOrigen" class="form-control provinciaOrigen">
        
        <?php if($provincias): ?>
            <?php $__currentLoopData = $provincias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $provincia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($key); ?>"
                 <?php if(isset($paciente)): ?><?php if($paciente->provinciaOrigen->id == $key): ?> selected="selected" <?php endif; ?> <?php endif; ?>><?php echo e($provincia); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
</div>