<div class="col-lg-12 col-md-12 col-sm-12">
    <table class="table table-responsive table-hover table-condensed small box">
        <thead>
        <th>HISTORIA</th>
        <th>PACIENTES</th>
        <th>DNI</th>
        <th>EDAD</th>
        <th>INFORMACIÓN</th>
        <th>OPCIONES</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $pacientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paciente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($paciente->estado): ?>

            <tr>
                <td><?php echo e($paciente->nro_historia); ?></td>
                <td class="text-left"><?php echo e($paciente->apellido_paterno.' '.$paciente->apellido_materno.' '.$paciente->nombres); ?></td>
                <td><?php echo e($paciente->num_dni); ?></td>
                <td>
                  <?php echo e(Carbon\Carbon::parse($paciente->fecha_nacimiento)->age.' años'); ?>

                </td>
                <td>
                    <form action="<?php echo e(route('pacientes.show',[$paciente->id])); ?>" method="get">
                        <button class="btn btn-xs btn-default"><span class="glyphicon glyphicon-info-sign"></span> DETALLE</button>
                    </form>
                </td>
                <td>
                    <a href="<?php echo e(route('pacientes.reporte',$paciente->id)); ?>" target="_blank" class="btn btn-xs btn-info "><span class="glyphicon glyphicon-print"></span> IMP.</a>
                    <a href="<?php echo e(route('pacientes.citas',[$paciente->id])); ?>" class="btn btn-xs btn-success cita"  id="<?php echo e($paciente->id); ?>"><span class="glyphicon glyphicon-plus"></span> CITAS</a>
                    <a href="<?php echo e(route('pacientes.edit',[$paciente->id])); ?>" class="btn btn-xs btn-warning editar"  id="<?php echo e($paciente->id); ?>"><span class="glyphicon glyphicon-pencil"></span> EDITAR</a>
                    <?php echo e(csrf_field()); ?>

                    <a href="#" class="btn btn-xs btn-danger delete"  id="<?php echo e($paciente->id); ?>"><span class="glyphicon glyphicon-remove"></span> ELIMINAR</a>
                </td>
            </tr>
            <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($pacientes->links()); ?>

</div>
