<?php $__env->startSection('api'); ?>
<style>
th,td{
    text-align: center;
}
strong{
  font-size: 15px;
}
</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header','CONFIGURACIONES'); ?>
<?php $__env->startSection('modal-title'); ?>
<h4 class="modal-title">Aviso</h4>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-body'); ?>
<h3 class="text-success text-center">Eliminación Exitosa</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-footer'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal-confirmacion-title'); ?>
<h4 class="modal-title">Aviso</h4>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-confirmacion-body'); ?>
<h3 class="text-warning text-center">¿Desea eliminar el registro?</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-confirmacion-footer'); ?>
<button class="btn btn-danger confirmar" id="">Confirmar</button>
<a href="" class="btn btn-warning " data-dismiss="modal" id="index" >Volver</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>




<div class="panel panel-body">
 <div class="">


    <div class="row text-center">
       <div class="col-md-2" >
        <a href="<?php echo e(route('tipoinstruccion.index')); ?>" class="btn btn-lg btn-block btn-default" ><h3><span class="fa fa-slideshare"></span></h3> <strong>Instrucción</strong></a>
    </div>
    <div class="col-md-2">
        <a href="<?php echo e(route('profesion.index')); ?>" class="btn btn-lg btn-block btn-default" ><h3><span class="fa fa-graduation-cap"></span></h3> <strong>Profesión</strong></a>
    </div>
    <div class="col-md-2">
        <a href="<?php echo e(route('contrata.index')); ?>" class="btn btn-lg btn-block btn-default" ><h3><span class="fa fa-building"></span></h3> <strong>Contrata</strong></a>
    </div>

    <div class="col-md-2">
        <a href="<?php echo e(route('area.index')); ?>" class="btn btn-lg btn-block btn-default" ><h3><span class="fa fa-cube"></span></h3> <strong>Área</strong></a>

    </div>


 </div>
<br>
<div class="row">
     <div class="col-md-2">
        <a href="<?php echo e(route('ocupaciones.index')); ?>" class="btn btn-lg btn-block btn-default" ><h3><span class="fa fa-briefcase"></span></h3> <strong>Ocupación</strong></a>
    </div>
    <div class="col-md-2">
        <a href="<?php echo e(route('lugarlabor.index')); ?>" class="btn btn-lg btn-block btn-default" ><h3><span class="fa fa-building-o"></span></h3> <strong>Lugar de Labor</strong></a>
    </div>

    <div class="col-md-2">
        <a href="<?php echo e(route('altura.index')); ?>" class="btn btn-lg btn-block btn-default" ><h3><span class="fa fa-arrow-up"></span></h3> <strong>Altura</strong></a>
    </div>
    <div class="col-md-2">
        <a href="<?php echo e(route('gruposanguineo.index')); ?>" class="btn btn-lg btn-block btn-default" ><h3><span class="fa fa-heart-o"></span></h3> <strong>Grupo Sanguíneo</strong></a>
    </div>


</div>


</div>
</div>
<h3>CITAS</h3>
<div class="panel panel-body">
 <div class="">


    <div class="row text-center">
       <div class="col-md-2" >
        <a href="<?php echo e(route('perfil.index')); ?>" class="btn btn-lg btn-block btn-default" ><h3><span class="fa fa-user-circle-o" style="font-size:25px"></span></h3> <strong>Perfil</strong></a>
    </div>
    <div class="col-md-2">
        <a href="<?php echo e(route('cliente_cuenta.index')); ?>" class="btn btn-lg btn-block btn-default" ><h3><span class="fa fa-id-card"></span></h3> <strong>Cliente Cuenta</strong></a>
    </div>
   

    <div class="col-md-2">
        <a href="<?php echo e(route('tipo_examen.index')); ?>" class="btn btn-lg btn-block btn-default" ><h3><span class="fa fa-list-alt"></span></h3> <strong>Tipo de Examen</strong></a>
    </div>

    <div class="col-md-2">
        <a href="<?php echo e(route('lista_examen.index')); ?>" class="btn btn-lg btn-block btn-default" ><h3><span class="fa fa-list"></span></h3> <strong>Lista de Examenes</strong></a>
    </div>
 </div>



</div>
</div>

<h3>USUARIOS</h3>
<div class="panel panel-body">
 <div class="">


    <div class="row text-center">

    <div class="col-md-2">
        <a href="<?php echo e(route('cargo.index')); ?>" class="btn btn-lg btn-block btn-default" ><h3><span class="fa fa-id-card-o"></span></h3> <strong>Cargos</strong></a>

    </div>


  <div class="col-md-2">
        <a href="<?php echo e(route('personal.index')); ?>" class="btn btn-lg btn-block btn-default" ><h3><span class="fa fa-users"></span></h3> <strong>Personal</strong></a>

    </div>

    <div class="col-md-2">
        <a href="<?php echo e(route('usuario.index')); ?>" class="btn btn-lg btn-block btn-default" ><h3><span class="fa fa-user"></span></h3> <strong>Usuarios</strong></a>

    </div>




    </div>



</div>
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('js/profesion.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>