<?php $__env->startSection('api'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    
        <h1 class="panel-title">
            <strong>
                Bienvenid@ <?php echo e(auth()->user()->personal->nombres); ?>

            </strong>
        </h1>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-6">
        <div class="panel panel-default">
            <div class="panel-heading">
                Citas para hoy
            </div>
            <div class="panel-body" style="padding:0px;">
                <div class="box" style="margin-bottom: 0px;">
                    <ul id="first-list">
                        <?php $__currentLoopData = $citas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <span>
                            </span>
                            <div class="title">
                                <?php echo e(Jenssegers\Date\Date::parse($cita->fecha_registro)->toFormattedDateString()); ?>

                            </div>
                            <div class="info">
                                <?php echo e($cita->paciente->nombres." ".$cita->paciente->apellido_paterno." ".$cita->paciente->apellido_materno); ?>

                            </div>
                            <div class="text-left">
                                Tipo de Examen : <span class="label label-warning"><?php echo e($cita->tipoexamen->descripcion); ?></span>
                            </div>
                            <div class="time">
                                <span>
                                    <?php echo e(Carbon\Carbon::parse($cita->hora_examen)->format('h:i A')); ?>

                                    <sup>
                                    </sup>
                                </span>
                                <span>
                                </span>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="panel panel-default">
            <div class="panel-heading">
                Opciones
            </div>
            <div class="panel-body" style="padding:0px;">
                <div style="height: 55vh;"></div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>