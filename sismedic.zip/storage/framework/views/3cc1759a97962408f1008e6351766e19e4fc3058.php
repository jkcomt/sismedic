

<form class="" action="index.html" method="post" id="registrar_antecedente_personal_dos">

  <?php echo csrf_field(); ?>
<div class="col-md-12">
  <div class="row form-group">
    <div class="col-md-2">
    </div>
    <div class="col-md-4">
    </div>
    <div class="col-md-6 text-right">
      <?php if(isset($paciente->antecendeDosPersonal)): ?>
        <button type="button" name="button" class="btn btn-sm btn-warning conformidadapdos" tipo="actualizardos">   Actualizar </button>
        <input type="hidden" name="antecedentesdos_id" value="<?php echo e($paciente->antecendeDosPersonal->id); ?>">
      <?php else: ?>
      <button type="button" name="button" class="btn btn-sm btn-success conformidadapdos" tipo="registrardos">Guardar</button>
      <?php endif; ?>
    </div>
  </div>
<input type="hidden" name="paciente_id" value="<?php echo e($cita->paciente->id); ?>">

  <div class="box box-default">
      <div class="box-header with-border">Información de Paciente
          <div class="box-tools pull-right">
              <button type="button" class="btn btn-box-tool" data-widget="collapse">
                  <i class="fa fa-plus"></i>
              </button>
          </div>
      </div>
      <div class="box-body">
          <div class="row col-md-12">

              <div class="row form-group">
                <div class="col-md-3">
                  <div class="input-group">
                    <span class="input-group-addon" style="padding-top:8px;padding-bottom:9px;">
                        <input type="checkbox" aria-label="" name="tuberculosis" id="tuberculosis" value="1" <?php if(isset($paciente->antecendeDosPersonal->tuberculosis)): ?> checked <?php endif; ?> onclick="activardos(this);">
                    </span>
                    <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Tuberculosis</span>
                    
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="input-group">
                    <span class="span-width input-group-addon">Año Dx</span>
                    <input type="text" class="form-control" aria-label="..." name="txttuberculosis" id="txttuberculosis"  <?php if(isset($paciente->antecendeDosPersonal->tuberculosis_anio_dx)): ?>  value="<?php echo e($paciente->antecendeDosPersonal->tuberculosis_anio_dx); ?>" <?php else: ?> readonly <?php endif; ?> >
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="input-group ">

                    <span class="input-group-addon span-width">Tiempo Tratamiento en meses</span>
                    <select class="form-control"    name="cbotuberculosis" id="cbotuberculosis">
                        <option value="1">OPTION 1</option>

                      </select>
                  </div>
                </div>
              </div>

              <div class="row form-group ">
                <div class="col-md-3">
                  <div class="input-group">
                    <span class="input-group-addon" style="padding-top:8px;padding-bottom:9px;">
                        <input type="checkbox" aria-label=""  onclick="activardos(this);" name="hepatitis" id="hepatitis" value="1" <?php if(isset($paciente->antecendeDosPersonal->hepatitis)): ?> checked <?php endif; ?>>
                    </span>
                    <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Hepatitis</span>
                    
                  </div>
                </div>

                <div class="col-md-5">
                      <select class="form-control" name="cbohepatitis"   id="cbohepatitis" <?php if(isset($paciente->antecendeDosPersonal->hepatitis)): ?> <?php else: ?> disabled  <?php endif; ?>   >
                          <option value="2">NADA</option>
                        </select>

                </div>

                <div class="col-md-4">
                  <div class="input-group">
                    <span class="span-width input-group-addon">Edad del Dx</span>
                    <input type="text" class="form-control" aria-label="..."  id="txthepatitis"  name="txthepatitis"  <?php if(isset($paciente->antecendeDosPersonal->hepatitis_edad)): ?> value="<?php echo e($paciente->antecendeDosPersonal->hepatitis_edad); ?>"  <?php else: ?> readonly <?php endif; ?> >
                  </div>
                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-3">
                  <div class="input-group">
                    <span class="input-group-addon" style="padding-top:8px;padding-bottom:9px;">
                        <input type="checkbox" aria-label="" onclick="activardos(this);" id="tifoidea"  name="tifoidea" value="1" <?php if(isset($paciente->antecendeDosPersonal->tifoidea)): ?> checked <?php endif; ?>>
                    </span>
                    <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Tifoidea</span>
                    
                  </div>
                </div>
                <div class="col-md-2">
                  <div class="input-group">
                    <span class="span-width input-group-addon">Año Dx</span>
                    <input type="text" class="form-control" aria-label="..." id="txttifoidea"  name="txttifoidea"   <?php if(isset($paciente->antecendeDosPersonal->tifoidea_ano_dx)): ?> value="<?php echo e($paciente->antecendeDosPersonal->tifoidea_ano_dx); ?>"  <?php else: ?> readonly <?php endif; ?> >
                  </div>
                </div>
                <div class="col-md-2">
                  <div class="input-group">
                    <span class="input-group-addon" style="padding-top:8px;padding-bottom:9px;">
                        <input type="checkbox" aria-label="" onclick="activardos(this);" id="brucelosis" name="brucelosis" value="1" <?php if(isset($paciente->antecendeDosPersonal->brucelosis)): ?> checked <?php endif; ?>>
                    </span>
                    <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Brucelosis</span>
                    
                  </div>

                </div>
                <div class="col-md-2">
                  <div class="input-group">
                    <span class="span-width input-group-addon">Año Dx</span>
                    <input type="text" class="form-control" aria-label="..." id="txtbrucelosis" name="txtbrucelosis" <?php if(isset($paciente->antecendeDosPersonal->brucelosis_anio_dx)): ?> value="<?php echo e($paciente->antecendeDosPersonal->brucelosis_anio_dx); ?>"  <?php else: ?> readonly <?php endif; ?>  >
                  </div>
                </div>
                <div class="col-md-3">

                  <div class="input-group">
                    <span class="input-group-addon" style="padding-top:8px;padding-bottom:9px;">
                        <input type="checkbox" aria-label=""  id="ulcerahepatica" name="ulcerahepatica" value="1" <?php if(isset($paciente->antecendeDosPersonal->ulcera_hepatica)): ?> checked <?php endif; ?>>
                    </span>
                    <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Úlcera Hepática</span>
                    
                  </div>
                </div>
              </div>

              <div class="row form-group">
                    <div class="col-md-4">
                      <div class="input-group ">
                        <span class="input-group-addon ">
                            <input type="checkbox" aria-label="" onclick="activardos(this);" id="convulsiones" name="convulsiones" value="1" <?php if(isset($paciente->antecendeDosPersonal->convulsiones)): ?> checked <?php endif; ?>>
                        </span>
                        <span class="input-group-addon span-width">Convulsiones</span>
                        <input type="text" class="form-control" aria-label="..."  id="txtconvulsiones" name="txtconvulsiones"  <?php if(isset($paciente->antecendeDosPersonal->convulsiones_descripcion)): ?> value="<?php echo e($paciente->antecendeDosPersonal->convulsiones_descripcion); ?>"  <?php else: ?> readonly <?php endif; ?> >
                      </div>
                    </div>
                    <div class="col-md-2">
                      <div class="input-group">
                        <span class="span-width input-group-addon">Año Dx</span>
                        <input type="text" class="form-control" aria-label="..."  id="txtanio" name="txtanio"  <?php if(isset($paciente->antecendeDosPersonal->convulsiones_ano_dx)): ?> value="<?php echo e($paciente->antecendeDosPersonal->convulsiones_ano_dx); ?>"  <?php else: ?> readonly <?php endif; ?>>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="input-group">
                        <span class="span-width input-group-addon">Tratamiento Actual</span>
                        <input type="text" class="form-control" aria-label="..." id="txtctratamientoactual"  name="txtctratamientoactual" <?php if(isset($paciente->antecendeDosPersonal->convulsiones_tratamiento_actual)): ?> value="<?php echo e($paciente->antecendeDosPersonal->convulsiones_tratamiento_actual); ?>"  <?php else: ?> readonly <?php endif; ?> >
                      </div>
                    </div>
              </div>

              <div class="row form-group">
                    <div class="col-md-4">
                      <div class="input-group ">
                        <span class="input-group-addon ">
                            <input type="checkbox" aria-label="" onclick="activardos(this);" id="gastritis" name="gastritis" value="1" <?php if(isset($paciente->antecendeDosPersonal->gastritis)): ?> checked <?php endif; ?>>
                        </span>
                        <span class="input-group-addon span-width">Gastritis</span>
                        <input type="text" class="form-control" aria-label="..."  id="txtgastritis" name="txtgastritis" <?php if(isset($paciente->antecendeDosPersonal->gastritis_descripcion)): ?> value="<?php echo e($paciente->antecendeDosPersonal->gastritis_descripcion); ?>"  <?php else: ?> readonly <?php endif; ?>>
                      </div>
                    </div>
                    <div class="col-md-2">
                      <div class="input-group">
                        <span class="span-width input-group-addon">Año Dx</span>
                        <input type="text" class="form-control" aria-label="..."  id="txtganio" name="txtganio" <?php if(isset($paciente->antecendeDosPersonal->gastritis_ano_dx)): ?> value="<?php echo e($paciente->antecendeDosPersonal->gastritis_ano_dx); ?>"  <?php else: ?> readonly <?php endif; ?>>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="input-group">
                        <span class="span-width input-group-addon">Tratamiento Actual</span>
                        <input type="text" class="form-control" aria-label="..." id="txtgtratamientoactual" name="txtgtratamientoactual"  <?php if(isset($paciente->antecendeDosPersonal->gastritis_tratamiento)): ?> value="<?php echo e($paciente->antecendeDosPersonal->gastritis_tratamiento); ?>"  <?php else: ?> readonly <?php endif; ?> >
                      </div>
                    </div>
              </div>

          </div>
      </div>
  </div>





    <div class="box box-default">
        <div class="box-header with-border">Información de Paciente
            <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse">
                    <i class="fa fa-plus"></i>
                </button>
            </div>
        </div>
        <div class="box-body">
            <div class="row col-md-12">


                <div class="row form-group">
                      <div class="col-md-4">
                        <div class="input-group ">
                          <span class="input-group-addon ">
                              <input type="checkbox" aria-label="" onclick="activardos(this);" id="erge" name="erge" value="1" <?php if(isset($paciente->antecendeDosPersonal->erge)): ?> checked <?php endif; ?>>
                          </span>
                          <span class="input-group-addon span-width">ERGE</span>
                          <input type="text" class="form-control" aria-label="..."  id="txterge" name="txterge" <?php if(isset($paciente->antecendeDosPersonal->erge_descripcion)): ?> value="<?php echo e($paciente->antecendeDosPersonal->erge_descripcion); ?>"  <?php else: ?> readonly <?php endif; ?>>
                        </div>
                      </div>
                      <div class="col-md-2">
                        <div class="input-group">
                          <span class="span-width input-group-addon">Año Dx</span>
                          <input type="text" class="form-control" aria-label="..."  id="txtergeanio" name="txtergeanio" <?php if(isset($paciente->antecendeDosPersonal->erge_ano_dx)): ?> value="<?php echo e($paciente->antecendeDosPersonal->erge_ano_dx); ?>"  <?php else: ?> readonly <?php endif; ?>>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="input-group">
                          <span class="span-width input-group-addon">Tratamiento Actual</span>
                          <input type="text" class="form-control" aria-label="..."  id="txtergetratamientoactual" name="txtergetratamientoactual" <?php if(isset($paciente->antecendeDosPersonal->erge_tratamiento_actual)): ?> value="<?php echo e($paciente->antecendeDosPersonal->erge_tratamiento_actual); ?>"  <?php else: ?> readonly <?php endif; ?>>
                        </div>
                      </div>
                </div>

                <div class="row form-group">
                      <div class="col-md-4">
                        <div class="input-group">
                          <span class="input-group-addon" style="padding-top:8px;padding-bottom:9px;">
                              <input type="checkbox" aria-label="" onclick="activardos(this);" id="urolitiasis" name="urolitiasis" value="1"  <?php if(isset($paciente->antecendeDosPersonal->urolitiasis)): ?> checked <?php endif; ?>>
                          </span>
                          <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Urolitiasis</span>
                          
                        </div>
                      </div>
                      <div class="col-md-2">
                        <div class="input-group">
                          <span class="span-width input-group-addon">Año Dx</span>
                          <input type="text" class="form-control" aria-label="..."  id="txturolitiasisanio" name="txturolitiasisanio" <?php if(isset($paciente->antecendeDosPersonal->urolitiasis_ano_dx)): ?> value="<?php echo e($paciente->antecendeDosPersonal->urolitiasis_ano_dx); ?>"  <?php else: ?> readonly <?php endif; ?> >
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="input-group">
                          <span class="span-width input-group-addon">Tratamiento Actual</span>
                          <input type="text" class="form-control" aria-label="..."  id="txturolitiasisaniotratamientoactual" name="txturolitiasisaniotratamientoactual" <?php if(isset($paciente->antecendeDosPersonal->urolitiasis_tratamiento_actual)): ?> value="<?php echo e($paciente->antecendeDosPersonal->urolitiasis_tratamiento_actual); ?>"  <?php else: ?> readonly <?php endif; ?> >
                        </div>
                      </div>
                </div>

                <div class="row form-group">
                      <div class="col-md-4">
                        <div class="input-group">
                          <span class="input-group-addon" style="padding-top:8px;padding-bottom:9px;">
                              <input type="checkbox" aria-label="" onclick="activardos(this);" name="herniainguinal" id="herniainguinal" value="1" <?php if(isset($paciente->antecendeDosPersonal->hernia_inguinal)): ?> checked <?php endif; ?> >
                          </span>
                          <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Hernia Inguinal</span>
                          
                        </div>
                      </div>

                      <div class="col-md-4">
                        <div class="input-group ">

                          <span class="input-group-addon span-width">Lado</span>
                          <select class="form-control" name="cboherniainguinal" id="cboherniainguinal" >
                              <option value="1">OPTION</option>
                            </select>
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="input-group">
                          <span class="span-width input-group-addon">Año Dx</span>
                          <input type="text" class="form-control" aria-label="..."  id="txtherniainguinal" name="txtherniainguinal"  <?php if(isset($paciente->antecendeDosPersonal->hernial_inguinal_ano_dx)): ?> value="<?php echo e($paciente->antecendeDosPersonal->hernial_inguinal_ano_dx); ?>"  <?php else: ?> readonly <?php endif; ?> >
                        </div>
                      </div>
                </div>

                <div class="row form-group">
                      <div class="col-md-4">
                        <div class="input-group">
                          <span class="input-group-addon" style="padding-top:8px;padding-bottom:9px;">
                              <input type="checkbox" aria-label="" onclick="activardos(this);" id="herniaumbilical" name="herniaumbilical" value="1"  <?php if(isset($paciente->antecendeDosPersonal->hernia_umbilical)): ?> checked <?php endif; ?>>
                          </span>
                          <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Hernia Umbilical</span>
                          
                        </div>
                      </div>
                      <div class="col-md-2">
                        <div class="input-group">
                          <span class="span-width input-group-addon">Año Dx</span>
                          <input type="text" class="form-control" aria-label="..." id="txtherniaumbilical"  name="txtherniaumbilical" <?php if(isset($paciente->antecendeDosPersonal->hernia_umbilical_ano_dx)): ?> value="<?php echo e($paciente->antecendeDosPersonal->hernia_umbilical_ano_dx); ?>"  <?php else: ?> readonly <?php endif; ?> >
                        </div>
                      </div>
                </div>

                <div class="row form-group">
                      <div class="col-md-4">
                        <div class="input-group">
                          <span class="input-group-addon" style="padding-top:8px;padding-bottom:9px;">
                              <input type="checkbox" aria-label=""  onclick="activardos(this);" id="lumbalgia" name="lumbalgia" value="1" <?php if(isset($paciente->antecendeDosPersonal->lumbalgia)): ?> checked <?php endif; ?> >
                          </span>
                          <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Lumbalgia</span>
                          
                        </div>
                      </div>

                      <div class="col-md-3">
                        <div class="input-group ">

                          <span class="input-group-addon span-width">Lado</span>
                          <select class="form-control"    id="cbolumbalgia" name="cbolumbalgia">
                              <option value="2">OPTION</option>
                            </select>
                        </div>
                      </div>
                      <div class="col-md-2">
                        <div class="input-group">
                          <span class="span-width input-group-addon">Año Dx</span>
                          <input type="text" class="form-control" aria-label="..." id="txtlumbalgiaanio" name="txtlumbalgiaanio" <?php if(isset($paciente->antecendeDosPersonal->lumbalgia_ano_dx)): ?> value="<?php echo e($paciente->antecendeDosPersonal->lumbalgia_ano_dx); ?>"  <?php else: ?> readonly <?php endif; ?> >
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="input-group">
                          <span class="span-width input-group-addon">Frecuencia Anual</span>
                          <input type="text" class="form-control" aria-label="..." id="txtlumbalgiafrecuenciaanual" name="txtlumbalgiafrecuenciaanual" <?php if(isset($paciente->antecendeDosPersonal->lumbalgia_frecuencia_actual)): ?> value="<?php echo e($paciente->antecendeDosPersonal->lumbalgia_frecuencia_actual); ?>"  <?php else: ?> readonly <?php endif; ?> >
                        </div>
                      </div>
                </div>

            </div>
        </div>
    </div>



      <div class="box box-default">
          <div class="box-header with-border">Información de Paciente
              <div class="box-tools pull-right">
                  <button type="button" class="btn btn-box-tool" data-widget="collapse">
                      <i class="fa fa-plus"></i>
                  </button>
              </div>
          </div>
          <div class="box-body">
              <div class="row col-md-12">


                  <div class="row form-group">
                        <div class="col-md-12">
                          <div class="input-group">
                            <span class="input-group-addon" style="padding-top:8px;padding-bottom:9px;">
                                <input type="checkbox" aria-label="" onclick="activardos(this);" id="otrostranstornoscolumna" name="otrostranstornoscolumna" value="1" <?php if(isset($paciente->antecendeDosPersonal->otros_transtornos_columna)): ?> checked <?php endif; ?>>
                            </span>
                            <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Otros Transtornos en la Columna</span>
                         <input type="text" class="form-control" aria-label="..."  id="txtotrostranstornoscolumna" name="txtotrostranstornoscolumna" <?php if(isset($paciente->antecendeDosPersonal->otros_transtornos_columna_descripcion)): ?> value="<?php echo e($paciente->antecendeDosPersonal->otros_transtornos_columna_descripcion); ?>"  <?php else: ?> readonly <?php endif; ?> >
                          </div>
                        </div>

                  </div>
                  <div class="row form-group">
                        <div class="col-md-12">
                          <div class="input-group">
                            <span class="input-group-addon" style="padding-top:8px;padding-bottom:9px;">
                                <input type="checkbox" aria-label="" onclick="activardos(this);" id="desordenespiel" name="desordenespiel" value="1" <?php if(isset($paciente->antecendeDosPersonal->desordenes_piel)): ?> checked <?php endif; ?> >
                            </span>
                            <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Desórdenes en la Piel</span>
                         <input type="text" class="form-control" aria-label="..."  id="txtdesordenespiel" name="txtdesordenespiel" <?php if(isset($paciente->antecendeDosPersonal->desordenes_piel_descripcion)): ?> value="<?php echo e($paciente->antecendeDosPersonal->desordenes_piel_descripcion); ?>"  <?php else: ?> readonly <?php endif; ?> >
                          </div>
                        </div>

                  </div>

                  <div class="row form-group">
                        <div class="col-md-12">
                          <div class="input-group">
                            <span class="input-group-addon" style="padding-top:8px;padding-bottom:9px;">
                                <input type="checkbox" aria-label="" onclick="activardos(this);" id="varicesmienbrosinferiores" name="varicesmienbrosinferiores" value="1" <?php if(isset($paciente->antecendeDosPersonal->varices_miembros_inferior)): ?> checked <?php endif; ?>>
                            </span>
                            <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Várices en Miembros Inferiores</span>
                         <input type="text" class="form-control" aria-label="..."  id="txtvaricesmienbrosinferiores" name="txtvaricesmienbrosinferiores" <?php if(isset($paciente->antecendeDosPersonal->varices_miembros_inferior_descripcion)): ?> value="<?php echo e($paciente->antecendeDosPersonal->varices_miembros_inferior_descripcion); ?>"  <?php else: ?> readonly <?php endif; ?> >
                          </div>
                        </div>

                  </div>

                  <div class="row form-group">
                        <div class="col-md-4">
                          <div class="input-group ">
                            <span class="input-group-addon ">
                                <input type="checkbox" aria-label="" onclick="activardos(this);" id="its" name="its" value="1" <?php if(isset($paciente->antecendeDosPersonal->its)): ?> checked <?php endif; ?>>
                            </span>
                            <span class="input-group-addon span-width">ITS</span>
                            <input type="text" class="form-control" aria-label="..."  id="txtits" name="txtits" <?php if(isset($paciente->antecendeDosPersonal->its_descripcion)): ?> value="<?php echo e($paciente->antecendeDosPersonal->its_descripcion); ?>"  <?php else: ?> readonly <?php endif; ?> >
                          </div>
                        </div>
                        <div class="col-md-2">
                          <div class="input-group">
                            <span class="span-width input-group-addon">Año Dx</span>
                            <input type="text" class="form-control" aria-label="..."  id="txtitsanio" name="txtitsanio" <?php if(isset($paciente->antecendeDosPersonal->its_ano_dx)): ?> value="<?php echo e($paciente->antecendeDosPersonal->its_ano_dx); ?>"  <?php else: ?> readonly <?php endif; ?>>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="input-group">
                            <span class="span-width input-group-addon">Tratamiento Actual</span>
                            <input type="text" class="form-control" aria-label="..."  id="txtitstratamientoactual" name="txtitstratamientoactual" <?php if(isset($paciente->antecendeDosPersonal->its_tratamiento_actual)): ?> value="<?php echo e($paciente->antecendeDosPersonal->its_tratamiento_actual); ?>"  <?php else: ?> readonly <?php endif; ?>>
                          </div>
                        </div>
                  </div>

                  <div class="row form-group">
                        <div class="col-md-12">
                          <div class="input-group">
                            <span class="input-group-addon" style="padding-top:8px;padding-bottom:9px;">
                                <input type="checkbox" aria-label="" onclick="activardos(this);" id="otros" name="otros_sintomas"  value="1" <?php if(isset($paciente->antecendeDosPersonal->otros_sintomas)): ?> checked <?php endif; ?>>
                            </span>
                            <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Otros</span>
                         <input type="text" class="form-control" aria-label="..."  id="txtotros" name="txtotrosdescripcion" <?php if(isset($paciente->antecendeDosPersonal->otros_sintomas_descripcion)): ?> value="<?php echo e($paciente->antecendeDosPersonal->otros_sintomas_descripcion); ?>"  <?php else: ?> readonly <?php endif; ?>>
                          </div>
                        </div>

                  </div>

                  <div class="row form-group">
                        <div class="col-md-12">
                          <div class="input-group">

                            <span class="span-width input-group-addon" style="padding-top:8px;padding-bottom:9px;">Sintomatología de los Últimos Seis Meses</span>
                         <input type="text" class="form-control" aria-label="..." name="sintomatologiaultimosmeses" <?php if(isset($paciente->antecendeDosPersonal->sintomatologia_6_meses)): ?> value="<?php echo e($paciente->antecendeDosPersonal->sintomatologia_6_meses); ?>"  <?php else: ?>  <?php endif; ?> >
                          </div>
                        </div>

                  </div>


              </div>
          </div>
      </div>


</div>

</form>
