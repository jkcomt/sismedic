<div class="col-lg-12 col-md-12 col-sm-12">
    <table class="table table-responsive table-hover table-condensed small box" id="tabla">
        <thead>
        <th>EXAMENES</th>
        <th>TIPO</th>
        <th>VALOR</th>
        <th>DSCTO</th>
        <th>OPCIONES</th>

        </thead>
        <tbody>
        <?php $__currentLoopData = $perfil->perfilExamen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $examen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($examen->estado): ?>
                <tr>

                    <td class="text-left"><?php echo e($examen->listaExamen->descripcion); ?></td>
                    <td><?php echo e($examen->listaExamen->tipo); ?></td>
                    <td><?php echo e($examen->listaExamen->valor); ?></td>
                    <td><?php echo e($examen->listaExamen->dscto); ?></td>
                     <td>
                        <?php echo e(csrf_field()); ?>


                        <button href="#" class="btn btn-xs btn-danger delete"  id="<?php echo e($examen->id); ?>"><span class="glyphicon glyphicon-remove"></span> ELIMINAR</button>
                    </td>
                </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php echo e($perfil->perfilExamen->links()); ?>

</div>
