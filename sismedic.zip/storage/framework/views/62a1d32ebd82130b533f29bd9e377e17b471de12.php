<?php $__env->startSection('api'); ?>
    <style>
        th,td{
            text-align: center;
        }
        #calendar {
            max-width: 900px;
            margin: 0 auto;
        }
    </style>

    <link rel="stylesheet" href="<?php echo e(asset('providers/fullcalendar/fullcalendar.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('providers/fullcalendar/fullcalendar.print.min.css')); ?>" media='print'>
    <script src="<?php echo e(asset('providers/fullcalendar/lib/moment.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('providers/fullcalendar/fullcalendar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('providers/fullcalendar/locale-all.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('providers/fullcalendar/scheduler.css')); ?>">
    <script src="<?php echo e(asset('providers/fullcalendar/scheduler.js')); ?>"></script>
    <script src="<?php echo e(asset('providers/calendario.js')); ?>"></script>
    <script>
        $(document).ready(function() {

            $('#calendar').fullCalendar({
                schedulerLicenseKey: 'CC-Attribution-NonCommercial-NoDerivatives',
                locale: 'es',
                aspectRatio: 2,
                eventLimit: true, // allow "more" link when too many events
                events: [
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        {
                            title : '<?php echo e($event->title); ?>',
                            start : '<?php echo e($event->start_date); ?>',
                            color : '<?php echo e($event->color); ?>',
                            id : '<?php echo e($event->id); ?>'
                            
                        },
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ],
                dayClick: function(date) {
                    $citas = 0;
                    var dayEvents = $('#calendar').fullCalendar( 'clientEvents' ,function(event){
                        if(event.start >= date && event.start <= date){
                            $citas = $citas + 1;
                        }
                    });

                    if($citas > 0){
                        listarCitas(date.format())
                    }

                }
            });

        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
  <div class="row">
    <div class="col-md-4">
      CALENDARIO DE CITAS
    </div>
    <div class="col-md-8 text-right">
      <a href="<?php echo e(route('citas.nuevacita')); ?>" class="btn btn-success">REGISTRAR NUEVA CITA</a>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="tabla">

</div>
<div class="panel panel-default" style="margin-bottom: 0px;">
    <div class="panel-body" style="padding-bottom: 10px;padding-top: 10px">
        <?php echo e(csrf_field()); ?>

        <div id='calendar'></div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>