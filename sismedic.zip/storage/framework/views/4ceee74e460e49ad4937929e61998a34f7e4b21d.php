<div class="col-lg-12 col-md-12 col-sm-12">
    <table class="table table-responsive table-hover table-condensed small box" id="tabla">
        <thead>
        <th>PERFILES</th>
        <th>EXAMENES ASOCIADOS AL PERFIL</th>
        <th>OPCIONES</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $perfiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perfil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($perfil->descripcion); ?></td>

                <td>
                     <a href="<?php echo e(route('perfil_examen.index',['id'=>$perfil->id])); ?>" class="btn btn-xs btn-info "> LISTA DE EXAMENES</a>

                </td>

                 <td>
                   <button class="btn btn-xs btn-warning edit"  value="<?php echo e($perfil->id); ?>"><span class="glyphicon glyphicon-pencil"></span> EDITAR</button>
                    <?php echo e(csrf_field()); ?>

                    

                    <button href="#" class="btn btn-xs btn-danger delete"  id="<?php echo e($perfil->id); ?>"><span class="glyphicon glyphicon-remove"></span> ELIMINAR</button>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</div>
