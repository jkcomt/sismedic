<div class="form-group">
    <select name="distritoOrigen" id="distritoOrigen" class="form-control distritoOrigen">
      <option value="">Seleccione Distrito</option>
        <?php if($distritos): ?>
            <?php $__currentLoopData = $distritos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $distrito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($key); ?>"
                        <?php if(isset($paciente)): ?><?php if($paciente->distritoOrigen->id == $key): ?> selected="selected" <?php endif; ?> <?php endif; ?>><?php echo e($distrito); ?></option>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
</div>
