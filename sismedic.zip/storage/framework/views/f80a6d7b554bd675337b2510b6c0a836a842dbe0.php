<?php $__env->startSection('api'); ?>
<style>
th,td{
    text-align: center;
}
</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header','LISTADO DE OCUPACIONES'); ?>
<?php $__env->startSection('modal-title'); ?>
<h4 class="modal-title">Aviso</h4>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-body'); ?>
<h3 class="text-success text-center">Registro Exitoso</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-footer'); ?>
<a class="btn btn-sm btn-warning" href="<?php echo e(route('ocupaciones.index')); ?>">Volver</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal-confirmacion-title'); ?>
<h4 class="modal-title">Aviso</h4>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-confirmacion-body'); ?>
<h3 class="text-warning text-center">¿Desea eliminar el registro?</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-confirmacion-footer'); ?>
<button class="btn btn-danger confirmar" id="">Confirmar</button>
<a href="" class="btn btn-warning " data-dismiss="modal" id="index" >Volver</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('ocupaciones.modals.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('ocupaciones.modals.edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<div class="row">
    <div class="col-md-8">
        <div class="form-group">
            <!--a href="" class="btn btn-success">NUEVA INSTRUCCION</a-->
                <a href="<?php echo e(route('configuracion.index')); ?>" class="btn btn-warning">VOLVER</a>
            <button class="btn btn-success new"> NUEVA OCUPACION</button>


        </div>
    </div>
    <div class="col-md-4">
        <form action="" class="form-inline text-right">
            
            
        </form>
    </div>
</div>
<br>
<div class="row" id="tabla">
     
     <?php echo $__env->make('ocupaciones.table', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('js/ocupaciones.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>