<?php $__env->startSection('api'); ?>
    <style>
        th,td{
            text-align: center;
        }
    </style>

    <!-- Include Date Range Picker -->
    <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>

    <div class="row">
      <div class="col-md-10">
        LISTADO DE CITAS DEL PACIENTE : <?php echo e($paciente->apellido_paterno.' '.$paciente->apellido_materno.', '.$paciente->nombres); ?>


      </div>
      <div class="col-md-2 text-right">
    <a href="<?php echo e(route('pacientes.index')); ?>" class="btn btn-sm btn-warning">VOLVER</a>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-title'); ?>
    <h4 class="modal-title">Aviso</h4>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-body'); ?>
    <h3 class="text-success text-center">Eliminación Exitosa</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-footer'); ?>
    <a class="btn btn-sm btn-warning" href="<?php echo e(route('pacientes.citas',[$paciente->id])); ?>">Volver</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal-confirmacion-title'); ?>
    <h4 class="modal-title">Aviso</h4>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-confirmacion-body'); ?>
    <h3 class="text-warning text-center">¿Desea eliminar el registro?</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-confirmacion-footer'); ?>
    <button class="btn btn-danger confirmar" id="">Confirmar</button>
    <a href="" class="btn btn-warning " data-dismiss="modal" id="index" >Volver</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    

    <div class="row">
        <div class="col-md-5">
            <div class="form-group">
              <a href="<?php echo e(route('pacientes.citas_paciente',[$paciente->id])); ?>" target="_blank"  class="btn btn-info"><span class="glyphicon glyphicon-print"></span> REPORTE DE CITAS POR PACIENTE</a>

                <a href="<?php echo e(route('pacientes.citas.create',[$paciente->id])); ?>" class="btn btn-success">NUEVA CITA</a>
                <input type="hidden" value="<?php echo e($paciente->id); ?>" id="idPaciente">
            </div>
        </div>
        <div class="col-md-7">
            <form action="" class="form-inline text-right">

              <div class="row">
                <div class="col-md-4">
                  <select class="form-control" name="tipoBusquedacita" id="tipoBusquedacita">
                    <option value="cita">POR N° CITA</option>
                    <option value="fecha">POR FECHA</option>
                  </select>
                </div>
                <div class="col-md-4">
                  <input type="text" id="buscarCita" placeholder="N° DE CITA A BUSCAR" class="form-control" >

               </div>
               <div class="col-md-4">
                 <input type="text" id="daterangecita"  class="form-control pull-right" name="daterangecita" style="width: 100%">
                </div>
              </div>

            </form>

        </div>
    </div>
    <div class="row" id="tabla">
        <?php echo $__env->make('pacientes.citas.tabla', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

  <script type="text/javascript" src="//cdn.jsdelivr.net/jquery/1/jquery.min.js"></script>
  <script type="text/javascript" src="//cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
  <script type="text/javascript" src="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.js"></script>
    <script src="<?php echo e(asset('js/pacientes/citas.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>