<?php $__env->startSection('api'); ?>
  
     <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.css" />
<style>
th,td{
    text-align: center;
}
</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header','LISTADO DE CITAS'); ?>
<?php $__env->startSection('modal-title'); ?>
<h4 class="modal-title">Aviso</h4>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-body'); ?>
<h3 class="text-success text-center">Registro Exitoso</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-footer'); ?>
<a class="btn btn-sm btn-warning" href="<?php echo e(route('citas.catalogo')); ?>">Volver</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal-confirmacion-title'); ?>
<h4 class="modal-title">Aviso</h4>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-confirmacion-body'); ?>
<h3 class="text-warning text-center">¿Desea eliminar el registro?</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-confirmacion-footer'); ?>
<button class="btn btn-danger confirmar" id="">Confirmar</button>
<a href="" class="btn btn-warning " data-dismiss="modal" id="index" >Volver</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('altura.modals.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('altura.modals.edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<div class="row">
    <div class="col-md-5">
        <div class="form-group">
                <a href="<?php echo e(route('citas.listareporte')); ?>" target="_blank"  class="btn btn-info"><span class="glyphicon glyphicon-print"></span> REPORTE GENERAL DE CITAS</a>
                <a href="<?php echo e(route('citas.nuevacita')); ?>" class="btn btn-success">NUEVA CITA</a>
        </div>
    </div>
    <div class="col-md-7">
        
          <div class="row">
            <div class="col-md-4">
              <select class="form-control" name="tipoBusqueda" id="tipoBusqueda">
                <option value="dni">POR DNI</option>
                <option value="fecha">POR FECHA</option>
                <option value="dni_fecha">POR DNI Y FECHA</option>
              </select>
            </div>
            <div class="col-md-4">
              <input type="text" id="buscarCitaDni" placeholder="BUSCAR CITAS POR DNI..." class="form-control" style="width: 100%">
           </div>
           <div class="col-md-4">
             <input type="text" id="daterange"  class="form-control pull-right" name="daterange" style="width: 100%">
            </div>
          </div>
        
    </div>
</div>

<div class="row" id="tabla">
     <?php echo $__env->make('citas.table', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
  <script type="text/javascript" src="//cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
  <script type="text/javascript" src="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.js"></script>
  <script src="<?php echo e(asset('js/pacientes/citas.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>