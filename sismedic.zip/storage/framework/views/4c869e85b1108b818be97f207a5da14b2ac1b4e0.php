<div class="row altura-md">

    <?php $__currentLoopData = $perfilesExamenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perfilesExamen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="row item">
            <div class="col-md-8 borde-inferior "><?php echo e($perfilesExamen->listaExamen->descripcion); ?> </div>
            <div class="col-md-1 text-center borde-inferior"><?php echo e($perfilesExamen->listaExamen->tipo); ?></div>
            <div class="col-md-1 text-center borde-inferior"><?php echo e($perfilesExamen->listaExamen->valor); ?></div>
            <div class="col-md-1 text-center borde-inferior"><?php echo e($perfilesExamen->listaExamen->dscto); ?></div>
            <?php if(isset($citax)): ?>
                <div class="col-md-1 text-center borde-inferior">
                  <input type="checkbox" value="<?php echo e($perfilesExamen->id); ?>" style="margin-top:0px;" name="check"
                <?php $__currentLoopData = $citax->citaExamen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $examen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($examen->item_examen_id == $perfilesExamen->id): ?>
                         checked
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 ></div>
            <?php endif; ?>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
