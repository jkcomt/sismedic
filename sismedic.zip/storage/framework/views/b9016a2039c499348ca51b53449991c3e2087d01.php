<div class="col-lg-12 col-md-12 col-sm-12">
    <table class="table table-responsive table-hover table-condensed small box" id="tabla">
        <thead>
        <th>EXAMEN</th>
        <th>TIPO</th>
          <th>VALOR</th>
          <th>DESCUENTO</th>
            <th>OPCIONES</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $listaexamenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listaexamen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($listaexamen->descripcion); ?></td>
                <td><?php echo e($listaexamen->tipo); ?></td>
                <td><?php echo e($listaexamen->valor); ?></td>
                <td><?php echo e($listaexamen->dscto); ?></td>
                 <td>
                   <button class="btn btn-xs btn-warning edit"  value="<?php echo e($listaexamen->id); ?>"><span class="glyphicon glyphicon-pencil"></span> EDITAR</button>
                    <?php echo e(csrf_field()); ?>

                    

                    <button href="#" class="btn btn-xs btn-danger delete"  id="<?php echo e($listaexamen->id); ?>"><span class="glyphicon glyphicon-remove"></span> ELIMINAR</button>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php echo e($listaexamenes->links()); ?>

</div>
