<div class="col-lg-12 col-md-12 col-sm-12">
    <table class="table table-responsive table-hover table-condensed small box">
        <thead>
        <th>Nro. HISTORIA</th>
        <th>Nro. CITA</th>
        <th>PACIENTE</th>
        <th>FECHA - HORA</th>
        <th>OPCIONES</th>
        </thead>
        <tbody>
        <?php if(isset($citas)): ?>
            <?php $__currentLoopData = $citas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($cita->paciente->nro_historia); ?></td>
                    <td><?php echo e($cita->nro_serie_cita); ?></td>
                    <td><?php echo e($cita->paciente->apellido_paterno.' '.$cita->paciente->apellido_materno.' '.$cita->paciente->nombres); ?></td>
                    <td><?php echo e($cita->fecha_examen.' - '.Carbon\Carbon::parse($cita->hora_examen)->format('h:i A')); ?></td>
                    <td>
                        
                        <?php echo e(csrf_field()); ?>



                        <?php if(isset($cita->funcionVital)): ?>
                        
                        <a href="<?php echo e(route('funcion_vital.edit',[$cita->id])); ?>" class="btn btn-xs btn-warning editar"  id=""><span class="glyphicon glyphicon-pencil"></span> EDITAR</a>
                        <a href="#" class="btn btn-xs btn-danger conformidad" tipo="eliminar"  id="<?php echo e($cita->funcionVital->id); ?>" ><span class="glyphicon glyphicon-remove"></span> ELIMINAR</a>
                        <a href="<?php echo e(route('funcion_vital.show',$cita)); ?>" class="btn btn-xs btn-success"  id=""><span class="glyphicon glyphicon-info-sign"></span> DETALLE DE FUNCIONES VITALES</a>

                        <?php else: ?>
                            <a href="<?php echo e(route('funcion_vital.create',$cita->id)); ?>" class="btn btn-xs btn-info"  id=""><span class="glyphicon glyphicon-info-sign"></span> REGISTRAR FUNCIONES VITALES</a>
                        <?php endif; ?>

                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        </tbody>
    </table>
    <?php echo e($citas->links()); ?>

</div>
