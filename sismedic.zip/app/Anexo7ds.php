<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Anexo7ds extends Model
{
    protected  $table = "anexo7ds";
    public $timestamps = false;
}
