<?php

namespace App\Http\Controllers;

use App\Anexo7ds;
use Illuminate\Http\Request;

class Anexo7dsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Anexo7ds  $anexo7ds
     * @return \Illuminate\Http\Response
     */
    public function show(Anexo7ds $anexo7ds)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Anexo7ds  $anexo7ds
     * @return \Illuminate\Http\Response
     */
    public function edit(Anexo7ds $anexo7ds)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Anexo7ds  $anexo7ds
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Anexo7ds $anexo7ds)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Anexo7ds  $anexo7ds
     * @return \Illuminate\Http\Response
     */
    public function destroy(Anexo7ds $anexo7ds)
    {
        //
    }
}
