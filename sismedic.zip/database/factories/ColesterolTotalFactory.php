<?php

use Faker\Generator as Faker;

$factory->define(App\ColesterolTotal::class, function (Faker $faker) {
    return [
        //
    ];
});
