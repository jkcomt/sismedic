<?php

use Faker\Generator as Faker;

$factory->define(App\EvaluacionConductorOperador::class, function (Faker $faker) {
    return [
        //
    ];
});
