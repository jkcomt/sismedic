<?php

use Faker\Generator as Faker;

$factory->define(App\AntperHistoriaOcupacionales::class, function (Faker $faker) {
    return [
        //
    ];
});
