<?php

use Faker\Generator as Faker;

$factory->define(App\AntecendeDosPersonal::class, function (Faker $faker) {
    return [
        //
    ];
});
