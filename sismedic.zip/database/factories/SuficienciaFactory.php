<?php

use Faker\Generator as Faker;

$factory->define(App\Suficiencia::class, function (Faker $faker) {
    return [
        //
    ];
});
