<?php

use Faker\Generator as Faker;

$factory->define(App\ColesterolHdl::class, function (Faker $faker) {
    return [
        //
    ];
});
