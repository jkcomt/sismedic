<?php

use Faker\Generator as Faker;

$factory->define(App\EvaluacionCognitiva::class, function (Faker $faker) {
    return [
        //
    ];
});
