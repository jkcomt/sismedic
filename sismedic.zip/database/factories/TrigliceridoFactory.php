<?php

use Faker\Generator as Faker;

$factory->define(App\Triglicerido::class, function (Faker $faker) {
    return [
        //
    ];
});
