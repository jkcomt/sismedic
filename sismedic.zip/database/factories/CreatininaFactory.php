<?php

use Faker\Generator as Faker;

$factory->define(App\Creatinina::class, function (Faker $faker) {
    return [
        //
    ];
});
