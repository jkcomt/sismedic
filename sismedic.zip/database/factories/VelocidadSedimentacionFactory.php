<?php

use Faker\Generator as Faker;

$factory->define(App\VelocidadSedimentacion::class, function (Faker $faker) {
    return [
        //
    ];
});
