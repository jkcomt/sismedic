<?php

use Faker\Generator as Faker;

$factory->define(App\AntecedentesNeumologicos::class, function (Faker $faker) {
    return [
        //
    ];
});
