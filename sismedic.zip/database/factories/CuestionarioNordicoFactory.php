<?php

use Faker\Generator as Faker;

$factory->define(App\CuestionarioNordico::class, function (Faker $faker) {
    return [
        //
    ];
});
