<?php

use Faker\Generator as Faker;

$factory->define(App\Electrocardiograma::class, function (Faker $faker) {
    return [
        //
    ];
});
