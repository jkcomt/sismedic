<?php

use Faker\Generator as Faker;

$factory->define(App\Vision::class, function (Faker $faker) {
    return [
        //
    ];
});
