<?php

use Faker\Generator as Faker;

$factory->define(App\AcidoUrico::class, function (Faker $faker) {
    return [
        //
    ];
});
