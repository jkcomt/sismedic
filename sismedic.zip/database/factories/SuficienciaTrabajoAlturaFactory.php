<?php

use Faker\Generator as Faker;

$factory->define(App\SuficienciaTrabajoAltura::class, function (Faker $faker) {
    return [
        //
    ];
});
