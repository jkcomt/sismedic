<?php

use Faker\Generator as Faker;

$factory->define(App\AntecedentesGinecologicos::class, function (Faker $faker) {
    return [
        //
    ];
});
