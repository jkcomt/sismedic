<?php

use Faker\Generator as Faker;

$factory->define(App\AntecedentesQuirurgicos::class, function (Faker $faker) {
    return [
        //
    ];
});
