<?php

use Faker\Generator as Faker;

$factory->define(App\AntecedentesOculares::class, function (Faker $faker) {
    return [
        //
    ];
});
