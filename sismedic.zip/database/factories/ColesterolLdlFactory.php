<?php

use Faker\Generator as Faker;

$factory->define(App\ColesterolLdl::class, function (Faker $faker) {
    return [
        //
    ];
});
