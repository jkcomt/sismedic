<?php

use Faker\Generator as Faker;

$factory->define(App\AntperAccidenteParticulares::class, function (Faker $faker) {
    return [
        //
    ];
});
