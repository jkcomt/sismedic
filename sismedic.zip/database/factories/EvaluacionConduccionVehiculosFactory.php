<?php

use Faker\Generator as Faker;

$factory->define(App\EvaluacionConduccionVehiculos::class, function (Faker $faker) {
    return [
        //
    ];
});
