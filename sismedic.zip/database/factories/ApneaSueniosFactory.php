<?php

use Faker\Generator as Faker;

$factory->define(App\ApneaSuenios::class, function (Faker $faker) {
    return [
        //
    ];
});
