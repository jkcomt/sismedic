<?php

use Faker\Generator as Faker;

$factory->define(App\FuncionVital::class, function (Faker $faker) {
    return [
        //
    ];
});
