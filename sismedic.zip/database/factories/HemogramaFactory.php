<?php

use Faker\Generator as Faker;

$factory->define(App\Hemograma::class, function (Faker $faker) {
    return [
        //
    ];
});
