<?php

use Faker\Generator as Faker;

$factory->define(App\Anexo7ds::class, function (Faker $faker) {
    return [
        //
    ];
});
