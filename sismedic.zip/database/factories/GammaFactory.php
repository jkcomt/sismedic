<?php

use Faker\Generator as Faker;

$factory->define(App\Gamma::class, function (Faker $faker) {
    return [
        //
    ];
});
