<?php

use Faker\Generator as Faker;

$factory->define(App\EncargadoAudiometrias::class, function (Faker $faker) {
    return [
        //
    ];
});
