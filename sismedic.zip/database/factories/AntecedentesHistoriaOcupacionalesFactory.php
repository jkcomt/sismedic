<?php

use Faker\Generator as Faker;

$factory->define(App\AntecedentesHistoriaOcupacionales::class, function (Faker $faker) {
    return [
        //
    ];
});
