<?php

use Faker\Generator as Faker;

$factory->define(App\Glucosa::class, function (Faker $faker) {
    return [
        //
    ];
});
