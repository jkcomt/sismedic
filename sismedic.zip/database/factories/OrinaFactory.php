<?php

use Faker\Generator as Faker;

$factory->define(App\Orina::class, function (Faker $faker) {
    return [
        //
    ];
});
