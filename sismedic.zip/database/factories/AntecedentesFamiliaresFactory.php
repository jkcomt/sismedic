<?php

use Faker\Generator as Faker;

$factory->define(App\AntecedentesFamiliares::class, function (Faker $faker) {
    return [
        //
    ];
});
