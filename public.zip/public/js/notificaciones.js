var getNewNotifications = function () {
    /*$.getJSON('/secado/notifications', function (data) {
        $('.notificaciones').text('')
        $('.notificaciones').append(data.html)

    });*/
};

//setInterval(getNewNotifications, 10000);
